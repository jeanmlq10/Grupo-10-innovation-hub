import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'features/auth/ui/viewmodels/authentication_controller.dart';
import 'features/auth/ui/views/welcome_page.dart';
import 'features/home/ui/views/home_page.dart';

class Central extends StatelessWidget {
  const Central({super.key});

  @override
  Widget build(BuildContext context) {
    AuthenticationController authenticationController = Get.find();
    return Obx(() {
      if (authenticationController.isRestoring) {
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      }
      return authenticationController.isLogged
          ? const HomePage()
          : const WelcomePage();
    });
  }
}
